#!/bin/bash
jvm/bin/java -jar LAPApp.jar -l lap -s lap/state -text_only